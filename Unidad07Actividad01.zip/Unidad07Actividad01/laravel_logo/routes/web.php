<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuarioController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/* Incluye todas las rutas necesarias para redireccionar. */

Route::get('/usuarios', [UsuarioController::class, 'index']);

Route::get('/usuarios/datos/{id}', [UsuarioController::class, 'show']);

Route::get('/usuarios/alta', [UsuarioController::class, 'create']);

Route::post('/usuarios/alta', [UsuarioController::class, 'store']);

Route::get('/usuarios/editar/{id}', [UsuarioController::class, 'edit']);

Route::post('/usuarios/editar/{id}', [UsuarioController::class, 'update']);

Route::get('/usuarios/borrar/{id}', [UsuarioController::class, 'destroy']);