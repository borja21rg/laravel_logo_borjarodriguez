<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usuarios extends Model
{
    use HasFactory;
    /* Añado esa variable en false para que no se añadan los campos de updated_at y created_at y deje introducir registros */
    public $timestamps = false;

    protected $table = "usuarioLogo";
    protected $primaryKey = "id";
    protected $fillable = ['clave', 'nombreUsuario', 'descripcion', 'perfil', 'activo'];
    /* Poner como hidden update y create no es del todo necesario gracias a la variable timestamps de arriba */
    protected $hidden = ['id', 'updated_at', 'created_at'];

}
