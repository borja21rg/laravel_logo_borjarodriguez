<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>Alta usuario</title>
    </head>
    <body>
        <h3>Alta usuario</h3>
        <form action="/usuarios/alta" method="POST">
            <?php echo csrf_field(); ?>
            <p>Clave: <input type="text" name="clave" ></p>
            <p>Nombre de usuario: <input type="text" name="nombreUsuario"></p>
            <p>Descripcion: <input type="text" name="descripcion" ></p>
            <p>Perfil: <input type="text" name="perfil" ></p>
            <p>Activo: <input type="text" name="activo" ></p>
            
            <p><input type="submit" value="Guardar"></p>
        </form>
        <a href="/usuarios">Ir a la tabla de usuarios<a>
    </body>
</html><?php /**PATH /var/www/html/laravel_logo/resources/views/usuarios/altausuario.blade.php ENDPATH**/ ?>