<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>Alta usuario</title>
    </head>
    <body>
        <h3>Alta usuario</h3>
        <form action="/usuarios/editar/<?php echo e($usuarios->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <p>Clave: <input type="text" name="clave" value=" <?php echo e($usuarios->clave); ?>"></p>
            <p>Nombre de usuario: <input type="text" name="nombreUsuario" value=" <?php echo e($usuarios->nombreUsuario); ?>"></p>
            <p>Descripcion: <input type="text" name="descripcion" value=" <?php echo e($usuarios->descripcion); ?>"></p>
            <p>Perfil: <input type="text" name="perfil" value=" <?php echo e($usuarios->perfil); ?>"></p>
            <p>Activo: <input type="text" name="activo" value=" <?php echo e($usuarios->activo); ?>"></p>
        
            
            <p><input type="submit" value="Guardar"></p>
        </form>
        <a href="/usuarios">Ir a la tabla de usuarios<a>
    </body>
</html><?php /**PATH /var/www/html/laravel_logo/resources/views/usuarios/editarusuario.blade.php ENDPATH**/ ?>