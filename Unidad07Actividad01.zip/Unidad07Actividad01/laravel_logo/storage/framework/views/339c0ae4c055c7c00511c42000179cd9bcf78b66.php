<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>Tabla usuarios</title>
    </head>
    <body>
        <h3>Tabla de usuarios</h3>
        <table border='1'>
            <tr>
                <th>Clave</th>
                <th>Nombre Usuario</th>
                <th>Descripcion</th>
                <th>Perfil</th>
                <th>Activo</th>
            </tr>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario-> clave); ?></td>
                    <td><?php echo e($usuario-> nombreUsuario); ?></td>
                    <td><?php echo e($usuario-> descripcion); ?></td>
                    <td><?php echo e($usuario-> perfil); ?></td>
                    <td><?php echo e($usuario-> activo); ?></td>
                    <td>
                        <a href="/usuarios/datos/<?php echo e($usuario->id); ?>">Datos<a>
                        <a href="/usuarios/editar/<?php echo e($usuario->id); ?>">Editar<a>
                        <a href="/usuarios/borrar/<?php echo e($usuario->id); ?>">Borrar<a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="/usuarios/alta">Nuevo usuario<a>
    </body>
</html><?php /**PATH /var/www/html/laravel_logo/resources/views/usuarios/tablausuarios.blade.php ENDPATH**/ ?>