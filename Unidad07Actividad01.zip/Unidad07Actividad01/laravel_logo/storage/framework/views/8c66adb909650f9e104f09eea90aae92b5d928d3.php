<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <title>Datos usuario</title>
    </head>
    <body>
        <h3>Datos usuario</h3>
        <form action="/usuarios/alta" method="GET">
            <p>Clave: <input type="text" name="clave" value=" <?php echo e($usuarios->clave); ?>" disabled></p>
            <p>Nombre de usuario: <input type="text" name="nombreUsuario" value=" <?php echo e($usuarios->nombreUsuario); ?>" disabled></p>
            <p>Descripcion: <input type="text" name="descripcion" value=" <?php echo e($usuarios->descripcion); ?>" disabled></p>
            <p>Perfil: <input type="text" name="perfil" value=" <?php echo e($usuarios->perfil); ?>" disabled></p>
            <p>Activo: <input type="text" name="activo" value=" <?php echo e($usuarios->activo); ?>" disabled></p>
        </form>
        <br>
        <a href="/usuarios">Ir a la tabla de usuarios<a>
    </body>
</html><?php /**PATH /var/www/html/laravel_logo/resources/views/usuarios/datosusuario.blade.php ENDPATH**/ ?>