<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <title>Datos usuario</title>
    </head>
    <body>
        <h3>Datos usuario</h3>
        <form action="/usuarios/alta" method="GET">
            <p>Clave: <input type="text" name="clave" value=" {{ $usuarios->clave }}" disabled></p>
            <p>Nombre de usuario: <input type="text" name="nombreUsuario" value=" {{ $usuarios->nombreUsuario }}" disabled></p>
            <p>Descripcion: <input type="text" name="descripcion" value=" {{ $usuarios->descripcion }}" disabled></p>
            <p>Perfil: <input type="text" name="perfil" value=" {{ $usuarios->perfil }}" disabled></p>
            <p>Activo: <input type="text" name="activo" value=" {{ $usuarios->activo }}" disabled></p>
        </form>
        <br>
        <a href="/usuarios">Ir a la tabla de usuarios<a>
    </body>
</html>