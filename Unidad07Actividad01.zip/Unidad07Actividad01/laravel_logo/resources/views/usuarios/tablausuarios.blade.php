<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <title>Tabla usuarios</title>
    </head>
    <body>
        <h3>Tabla de usuarios</h3> <!-- Creamos la tabla donde se mostrarán los usuarios -->
        <table border='1'>
            <tr>
                <th>Clave</th>
                <th>Nombre Usuario</th>
                <th>Descripcion</th>
                <th>Perfil</th>
                <th>Activo</th>
            </tr>
            <!-- Rellena los campos por cada usuario -->
            @foreach ($usuarios as $usuario)
                <tr>
                    <td>{{ $usuario-> clave }}</td>
                    <td>{{ $usuario-> nombreUsuario }}</td>
                    <td>{{ $usuario-> descripcion }}</td>
                    <td>{{ $usuario-> perfil }}</td>
                    <td>{{ $usuario-> activo }}</td>
                    <td>
                        <a href="/usuarios/datos/{{$usuario->id}}">Datos<a>
                        <a href="/usuarios/editar/{{$usuario->id}}">Editar<a>
                        <a href="/usuarios/borrar/{{$usuario->id}}">Borrar<a>
                    </td>
                </tr>
            @endforeach
        </table>
        <!-- Redirije a la parte de crear un nuevo usuario -->
        <a href="/usuarios/alta">Nuevo usuario<a>
    </body>
</html>