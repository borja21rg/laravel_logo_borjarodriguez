<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <title>Alta usuario</title>
    </head>
    <body>
        <h3>Alta usuario</h3>
        <form action="/usuarios/editar/{{$usuarios->id}}" method="POST">
            @csrf
            <p>Clave: <input type="text" name="clave" value=" {{ $usuarios->clave }}"></p>
            <p>Nombre de usuario: <input type="text" name="nombreUsuario" value=" {{ $usuarios->nombreUsuario }}"></p>
            <p>Descripcion: <input type="text" name="descripcion" value=" {{ $usuarios->descripcion }}"></p>
            <p>Perfil: <input type="text" name="perfil" value=" {{ $usuarios->perfil }}"></p>
            <p>Activo: <input type="text" name="activo" value=" {{ $usuarios->activo }}"></p>
            <!-- Nos permite editar el usuario seleccionado y guardar esos nuevos datos. -->
            
            <p><input type="submit" value="Guardar"></p>
        </form>
        <a href="/usuarios">Ir a la tabla de usuarios<a>
    </body>
</html>